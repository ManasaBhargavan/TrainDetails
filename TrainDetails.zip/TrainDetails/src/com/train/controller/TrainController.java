package com.train.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;
import com.train.service.ITrainService;

@Controller
public class TrainController {
	
	@Autowired
	private ITrainService trainService;
	
	
	
	public ITrainService getTrainService() {
		return trainService;
	}

	public void setTrainService(ITrainService trainService) {
		this.trainService = trainService;
	}

	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("viewAllTrains")
	public ModelAndView showAllTrains(@ModelAttribute("train") TrainBean bean)
	{
		ModelAndView model=new ModelAndView();
		try {
			List<TrainBean> list=trainService.viewAllTrains();
			model.setViewName("view");
			model.addObject("list", list);
		} catch (TrainException e) {
			model.setViewName("error");
			model.addObject("message", e.getMessage());
		}
		return model;
		
	}
	
	public 

}
