package com.train.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TrainDetails")
public class TrainBean {
	
	@Id
	@Column(name="TrainId",length=6)
	private String trainId;
	
	@Column(name="TrainName",length=30)
	private String trainName;
	
	@Column(name="Destination",length=20)
	private String destination;
	
	@Column(name="DepartDate")
	private Date departDate;
	
	@Column(name="Seats")
	private int seats;
	
	@Column(name="Fare")
	private double fare;
	
	public String getTrainId() {
		return trainId;
	}
	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDepartDate() {
		return departDate;
	}
	public void setDepartDate(Date departDate) {
		this.departDate = departDate;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public TrainBean(String trainId, String trainName, String destination,
			Date departDate, int seats, double fare) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.destination = destination;
		this.departDate = departDate;
		this.seats = seats;
		this.fare = fare;
	}
	public TrainBean() {
		super();
	}
	@Override
	public String toString() {
		return "TrainBean [trainId=" + trainId + ", trainName=" + trainName
				+ ", destination=" + destination + ", departDate=" + departDate
				+ ", seats=" + seats + ", fare=" + fare + "]";
	}
	
	

}
