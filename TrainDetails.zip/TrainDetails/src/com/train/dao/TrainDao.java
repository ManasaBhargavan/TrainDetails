package com.train.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;

@Repository
@Transactional
public class TrainDao implements ITrainDao {

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		List<TrainBean> list;
		try {
		TypedQuery<TrainBean>query=entitymanager.createQuery("select t from TrainBean t", TrainBean.class);
		list = query.getResultList();
		} catch (Exception e) {
		throw new TrainException("unable to view all records in Dao layer"+ e.getMessage());
		}
		 
		return list;
		
	}

	@Override
	public TrainBean retrieveDetail(String trainId) throws TrainException {
		TrainBean bean;
		try {
			
			bean=entitymanager.find(TrainBean.class, trainId);
			
		} catch (Exception e) {
			throw new TrainException("unable to Search records in Dao layer"+ e.getMessage());
		}
		return bean;
	}
	

}
