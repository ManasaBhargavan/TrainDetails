package com.train.exception;

public class TrainException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2174878126365775489L;

	public TrainException(String message) {
		super(message);
	}
	

}
