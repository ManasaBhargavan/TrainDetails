package com.train.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.train.bean.TrainBean;
import com.train.dao.ITrainDao;
import com.train.dao.TrainDao;
import com.train.exception.TrainException;

@Service
public class TrainService implements ITrainService {
	
	@Autowired
	private ITrainDao TrainDao;
	
	

	public ITrainDao getTrainDao() {
		return TrainDao;
	}



	public void setTrainDao(ITrainDao trainDao) {
		TrainDao = trainDao;
	}



	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		return TrainDao.viewAllTrains();
	}



	@Override
	public TrainBean retrieveDetail(String trainId) throws TrainException {
		
		return null;
	}

}
